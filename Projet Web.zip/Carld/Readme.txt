Nom          Prenom           Niveau d'etude     Vacation
Erilus    Carld Rothschild      2e annee          Median